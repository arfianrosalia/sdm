-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.38-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for personalia
CREATE DATABASE IF NOT EXISTS `personalia` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `personalia`;

-- Dumping structure for table personalia.personalia_pegawai
CREATE TABLE IF NOT EXISTS `personalia_pegawai` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nik` text,
  `no_ktp` text,
  `nama_lengkap` text,
  `nama_singkat` text,
  `fungsional` text,
  `tmt` datetime DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `wilayah` int(11) DEFAULT NULL,
  `jabatan` int(11) DEFAULT NULL,
  `status_karyawan` int(11) DEFAULT NULL,
  `gelar` int(11) DEFAULT NULL,
  `tanggal_lahir` datetime DEFAULT NULL,
  `pendidikan` int(11) DEFAULT NULL,
  `agama` text,
  `kota_kelahiran` int(11) DEFAULT NULL,
  `status_pribadi` int(11) DEFAULT NULL,
  `alamat` text,
  `provinsi` int(11) DEFAULT NULL,
  `kode_pos` text,
  `kewarganegaraan` int(11) DEFAULT NULL,
  `no_telepon` text,
  `catatan` longtext,
  `nama_pasangan` text,
  `jumlah_anak` int(11) DEFAULT NULL,
  `atasan` bigint(20) DEFAULT NULL,
  `jenis_kelamin` tinytext,
  `foto` text,
  `status_keaktifan` int(1) DEFAULT NULL,
  `insert_by` int(11) DEFAULT NULL,
  `insert_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_by` int(11) DEFAULT NULL,
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `delete_by` int(11) DEFAULT NULL,
  `delete_date` datetime DEFAULT NULL,
  `is_delete` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table personalia.personalia_pegawai: ~0 rows (approximately)
/*!40000 ALTER TABLE `personalia_pegawai` DISABLE KEYS */;
/*!40000 ALTER TABLE `personalia_pegawai` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
