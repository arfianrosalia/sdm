<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datadata {
	public function user_personalia($d=null){
		
	}
}