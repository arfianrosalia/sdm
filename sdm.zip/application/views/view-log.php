
<form action="loginlogin/submit" method="POST">
    <input type="text" name="username">
    <input type="password" name="password">
    <button type="submit">SUBMIT</button>
</form>